package com.example.lists


data class Chiuit(val description : String)